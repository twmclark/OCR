using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace vision
{
    class Program
    {
    
        const string subscriptionKey = "61509e42d9be4f8eb5e3461574451bf3";


        const string uriBase =
            "https://westeurope.api.cognitive.microsoft.com/vision/v2.0/recognizeText?mode=Printed";

        static void Main(string[] args)
        {
            Console.WriteLine("Analyze an image:");
            Console.Write(
                "Enter the path to the image you wish to analyze: ");
            string imageFilePath = Console.ReadLine();

            if (File.Exists(imageFilePath))
            {
                // Call the REST API method.
                Console.WriteLine("\nWait a moment for the results to appear.\n");
                MakeAnalysisRequest(imageFilePath).Wait();
            }
            else
            {
                Console.WriteLine("\nInvalid file path");
            }
            Console.WriteLine("\nPress Enter to exit...");
            Console.ReadLine();
        }

        static async Task MakeAnalysisRequest(string imageFilePath)
        {
            try
            {
                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add(
                    "Ocp-Apim-Subscription-Key", subscriptionKey);


                byte[] byteData = GetImageAsByteArray(imageFilePath);

                // Add the byte array as an octet stream to the request body.
                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    // This example uses the "application/octet-stream" content type.
                    // The other content types you can use are "application/json"
                    // and "multipart/form-data".
                    content.Headers.ContentType =
                        new MediaTypeHeaderValue("application/octet-stream");

                    // Asynchronously call the REST API method.
                    var response = await client.PostAsync("https://westeurope.api.cognitive.microsoft.com/vision/v2.0/ocr?language=unk&detectOrientation=true", content);
                    var error = await response.Content.ReadAsStringAsync();

                }




                using (var imageStream = File.OpenRead(imageFilePath))
                {
                    var reqBody = new StreamContent(imageStream);
                    reqBody.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");
                    using (var rsp = await client.PostAsync("https://westeurope.api.cognitive.microsoft.com/vision/v2.0/recognizetext?mode=Printed", reqBody))
                    {
                        if (!rsp.IsSuccessStatusCode)
                        {
                            var error = await rsp.Content.ReadAsStringAsync();
                            Console.WriteLine($"Request failed: {error}");
                        }
                        else
                        {
                            var rspBody = await rsp.Content.ReadAsStringAsync();
                            var rspJson = JToken.Parse(rspBody);
                            Console.WriteLine(rspJson);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }
        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            // Open a read-only file stream for the specified file.
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                // Read the file's contents into a byte array.
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
